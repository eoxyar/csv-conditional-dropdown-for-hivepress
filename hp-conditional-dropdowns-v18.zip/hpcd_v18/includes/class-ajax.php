<?php
defined( 'ABSPATH' ) || exit;

class HPCD_Ajax {

    public static function init() {
        add_action( 'wp_ajax_hpcd_get_child_values',        array( __CLASS__, 'get_child_values' ) );
        add_action( 'wp_ajax_nopriv_hpcd_get_child_values', array( __CLASS__, 'get_child_values' ) );
        add_action( 'wp_ajax_hpcd_import_csv',              array( __CLASS__, 'import_csv' ) );
        add_action( 'wp_ajax_hpcd_export_csv',              array( __CLASS__, 'export_csv' ) );
        add_action( 'wp_ajax_hpcd_bulk_delete',             array( __CLASS__, 'bulk_delete' ) );
        add_action( 'wp_ajax_hpcd_add_row',                 array( __CLASS__, 'add_row' ) );
        add_action( 'wp_ajax_hpcd_delete_row',              array( __CLASS__, 'delete_row' ) );
    }

    public static function get_child_values() {
        $pair_id      = absint( isset( $_POST['pair_id'] )      ? $_POST['pair_id']      : 0 );
        $parent_value = sanitize_text_field( isset( $_POST['parent_value'] ) ? $_POST['parent_value'] : '' );

        $values = HPCD_DB::get_child_values( $pair_id, $parent_value );
        wp_send_json_success( array( 'values' => $values ) );
    }

    public static function add_row() {
        check_ajax_referer( 'hpcd_admin', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( 'Forbidden' ); }

        $pair_id      = absint( isset( $_POST['pair_id'] )      ? $_POST['pair_id']      : 0 );
        $parent_value = sanitize_text_field( isset( $_POST['parent_value'] ) ? $_POST['parent_value'] : '' );
        $child_value  = sanitize_text_field( isset( $_POST['child_value'] )  ? $_POST['child_value']  : '' );

        if ( ! $pair_id || ! $parent_value || ! $child_value ) {
            wp_send_json_error( 'Missing fields' );
        }

        $id = HPCD_DB::insert_data_row( $pair_id, $parent_value, $child_value );
        if ( ! $id ) {
            wp_send_json_error( 'Duplicate or DB error' );
        }

        wp_send_json_success( array( 'id' => $id ) );
    }

    public static function delete_row() {
        check_ajax_referer( 'hpcd_admin', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( 'Forbidden' ); }

        HPCD_DB::delete_data_row( absint( isset( $_POST['id'] ) ? $_POST['id'] : 0 ) );
        wp_send_json_success();
    }

    public static function bulk_delete() {
        check_ajax_referer( 'hpcd_admin', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( 'Forbidden' ); }

        $ids = isset( $_POST['ids'] ) ? array_map( 'absint', (array) $_POST['ids'] ) : array();
        if ( empty( $ids ) ) { wp_send_json_error( 'No IDs' ); }

        global $wpdb;
        $in      = implode( ',', $ids );
        $deleted = $wpdb->query( "DELETE FROM {$wpdb->prefix}hpcd_conditional_data WHERE id IN ($in)" );
        wp_send_json_success( array( 'deleted' => $deleted ) );
    }

    public static function import_csv() {
        check_ajax_referer( 'hpcd_admin', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( 'Forbidden' ); }

        $pair_id        = absint( isset( $_POST['pair_id'] )        ? $_POST['pair_id']        : 0 );
        $clear_existing = isset( $_POST['clear_existing'] )         && $_POST['clear_existing'] === 'true';

        if ( ! $pair_id || empty( $_FILES['csv_file'] ) ) {
            wp_send_json_error( 'Missing data' );
        }

        if ( $clear_existing ) {
            HPCD_DB::delete_data_for_pair( $pair_id );
        }

        $handle = fopen( $_FILES['csv_file']['tmp_name'], 'r' );
        if ( ! $handle ) { wp_send_json_error( 'Cannot open file' ); }

        $imported = 0;
        $skipped  = 0;

        while ( ( $row = fgetcsv( $handle, 1000, ',' ) ) !== false ) {
            if ( count( $row ) < 2 ) { $skipped++; continue; }
            $pv = sanitize_text_field( trim( $row[0] ) );
            $cv = sanitize_text_field( trim( $row[1] ) );
            if ( ! $pv || ! $cv ) { $skipped++; continue; }
            $res = HPCD_DB::insert_data_row( $pair_id, $pv, $cv );
            $res ? $imported++ : $skipped++;
        }

        fclose( $handle );
        wp_send_json_success( array( 'imported' => $imported, 'skipped' => $skipped ) );
    }

    public static function export_csv() {
        check_ajax_referer( 'hpcd_admin', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Forbidden' ); }

        $pair_id = absint( isset( $_GET['pair_id'] ) ? $_GET['pair_id'] : 0 );
        $pair    = HPCD_DB::get_pair( $pair_id );
        if ( ! $pair ) { wp_die( 'Not found' ); }

        $filename = sanitize_file_name( $pair->pair_name ) . '-' . date( 'Y-m-d' ) . '.csv';
        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
        header( 'Pragma: no-cache' );

        $out = fopen( 'php://output', 'w' );
        fprintf( $out, chr(0xEF) . chr(0xBB) . chr(0xBF) ); // BOM

        $rows = HPCD_DB::get_data( $pair_id, '', 999999 );
        foreach ( $rows as $r ) {
            fputcsv( $out, array( $r->parent_value, $r->child_value ) );
        }
        fclose( $out );
        exit;
    }
}
