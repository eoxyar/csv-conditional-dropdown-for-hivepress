( function ( $ ) {
    'use strict';

    var cfg    = window.hpcdAdmin || {};
    var AJAX   = cfg.ajax_url || '';
    var NONCE  = cfg.nonce    || '';
    var PAIR   = cfg.pair_id  || 0;
    var STR    = cfg.strings  || {};

    /* ── Add single row ─────────────────────────────────────────────── */
    $( '#hpcd-add-row-btn' ).on( 'click', function () {
        var pv  = $( '#hpcd-pv' ).val().trim();
        var cv  = $( '#hpcd-cv' ).val().trim();
        var $st = $( '#hpcd-add-status' );

        if ( ! pv || ! cv ) { $st.text( 'Both fields required.' ).css( 'color', '#c00' ); return; }

        $.post( AJAX, { action: 'hpcd_add_row', nonce: NONCE, pair_id: PAIR, parent_value: pv, child_value: cv }, function ( r ) {
            if ( r.success ) {
                /* Append row to table */
                var id  = r.data.id;
                var row = '<tr id="hpcd-row-' + id + '">'
                    + '<td><input type="checkbox" class="hpcd-row-cb" value="' + id + '"></td>'
                    + '<td>' + esc( pv ) + '</td>'
                    + '<td>' + esc( cv ) + '</td>'
                    + '<td><a href="#" class="button button-small hpcd-del-row" data-id="' + id + '" style="color:#c00;">&times;</a></td>'
                    + '</tr>';

                var $tbody = $( '#hpcd-data-tbody' );
                $tbody.find( 'td[colspan]' ).closest( 'tr' ).remove();
                $tbody.append( row );

                $( '#hpcd-pv, #hpcd-cv' ).val( '' );
                $st.text( 'Added!' ).css( 'color', '#155724' );
                setTimeout( function () { $st.text( '' ); }, 2000 );
            } else {
                $st.text( r.data || 'Error.' ).css( 'color', '#c00' );
            }
        } );
    } );

    /* ── Delete single row (AJAX — for dynamically-added rows) ─────── */
    $( document ).on( 'click', '.hpcd-del-row', function ( e ) {
        e.preventDefault();
        if ( ! confirm( STR.confirm_delete || 'Delete?' ) ) { return; }
        var id   = $( this ).data( 'id' );
        var $row = $( '#hpcd-row-' + id );
        $.post( AJAX, { action: 'hpcd_delete_row', nonce: NONCE, id: id }, function ( r ) {
            if ( r.success ) { $row.fadeOut( 200, function () { $row.remove(); } ); }
        } );
    } );

    /* ── Select all checkbox ─────────────────────────────────────────── */
    $( '#hpcd-select-all' ).on( 'change', function () {
        $( '.hpcd-row-cb' ).prop( 'checked', $( this ).prop( 'checked' ) );
    } );

    /* ── Bulk delete ──────────────────────────────────────────────────── */
    $( '#hpcd-bulk-delete' ).on( 'click', function () {
        var ids = $( '.hpcd-row-cb:checked' ).map( function () { return $( this ).val(); } ).get();
        if ( ! ids.length ) { return; }
        if ( ! confirm( STR.confirm_delete ) ) { return; }

        $.post( AJAX, { action: 'hpcd_bulk_delete', nonce: NONCE, ids: ids }, function ( r ) {
            if ( r.success ) {
                ids.forEach( function ( id ) {
                    $( '#hpcd-row-' + id ).remove();
                } );
            }
        } );
    } );

    /* ── CSV import ──────────────────────────────────────────────────── */
    $( '#hpcd-import-btn' ).on( 'click', function () {
        var file = $( '#hpcd-csv-file' )[0].files[0];
        if ( ! file ) { $( '#hpcd-import-status' ).text( 'Choose a CSV file first.' ); return; }

        var $st = $( '#hpcd-import-status' );
        $st.text( STR.importing || 'Importing…' );

        var fd = new FormData();
        fd.append( 'action',         'hpcd_import_csv' );
        fd.append( 'nonce',           NONCE );
        fd.append( 'pair_id',         PAIR );
        fd.append( 'clear_existing',  $( '#hpcd-csv-clear' ).is( ':checked' ) ? 'true' : 'false' );
        fd.append( 'csv_file',        file );

        $.ajax( {
            url:         AJAX,
            type:        'POST',
            data:        fd,
            processData: false,
            contentType: false,
            success: function ( r ) {
                if ( r.success ) {
                    var msg = ( STR.imported || 'Imported: %d, skipped: %d.' )
                        .replace( '%d', r.data.imported )
                        .replace( '%d', r.data.skipped );
                    $st.text( msg );
                    /* Reload table after import */
                    setTimeout( function () { location.reload(); }, 1200 );
                } else {
                    $st.text( r.data || STR.error );
                }
            },
            error: function () { $st.text( STR.error ); },
        } );
    } );

    /* ── Tiny HTML escape ────────────────────────────────────────────── */
    function esc( s ) {
        return String( s )
            .replace( /&/g, '&amp;' ).replace( /</g, '&lt;' )
            .replace( />/g, '&gt;' ).replace( /"/g, '&quot;' );
    }

} )( jQuery );

/* ── Icon live preview ───────────────────────────────────────────────── */
( function () {
    function bindIconPreview( inputId, previewId ) {
        var input   = document.getElementById( inputId );
        var preview = document.getElementById( previewId );
        if ( ! input || ! preview ) { return; }

        function update() {
            // Build exactly what HP renders: hp-icon fas fa-fw fa-{name}
            var name = input.value.trim().replace( /^(fa[srbldi]?)\s+fa-/, '' ).replace( /^fa-/, '' );
            preview.innerHTML = name ? '<i class="hp-icon fas fa-fw fa-' + name + '"></i>' : '';
        }

        input.addEventListener( 'input', update );
        update(); // run on page load for edit mode
    }

    document.addEventListener( 'DOMContentLoaded', function () {
        bindIconPreview( 'parent_icon_input', 'parent_icon_preview' );
        bindIconPreview( 'child_icon_input',  'child_icon_preview'  );

        /* Clickable tokens — click inserts token at cursor position */
        document.querySelectorAll( '.hpcd-token' ).forEach( function ( token ) {
            token.addEventListener( 'click', function () {
                var targetId = token.getAttribute( 'data-target' );
                var input    = document.querySelector( '[name="' + targetId + '"]' );
                if ( ! input ) { return; }
                var val   = token.textContent.trim();
                var start = input.selectionStart;
                var end   = input.selectionEnd;
                input.value = input.value.substring( 0, start ) + val + input.value.substring( end );
                input.focus();
                input.selectionStart = input.selectionEnd = start + val.length;
            } );
        } );
    } );
} )();
