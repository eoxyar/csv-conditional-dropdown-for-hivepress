/**
 * HivePress Conditional Dropdowns — Frontend  v2.0.2
 *
 * hpcdData structure (injected inline by PHP):
 * {
 *   "make": {
 *     id: 1,
 *     parent_field: "make",
 *     child_field: "model",
 *     rules: { "Toyota": ["Corolla","Camry"], "Honda": ["Civic","Accord"] },
 *     category_ids: [12, 15]   ← [] = all categories
 *   }
 * }
 *
 * Category filtering strategy:
 *   - If category_ids is empty → pair is active on ALL categories.
 *   - If category_ids has entries → pair is only active when the current
 *     listing category (read from the category field in the same form)
 *     matches one of the IDs.
 *   - We watch the category field for changes and re-evaluate visibility.
 */
( function ( $ ) {
    'use strict';

    var DATA = window.hpcdData || {};
    if ( ! Object.keys( DATA ).length ) { return; }

    /* ── Option snapshots (slug → {val: label}) ────────────────────── */
    var snapshots = {};

    /* ── Internal mutation pause flag ───────────────────────────────── */
    var _pauseObserver = false;
    window._hpcdPauseObserver = function() { return _pauseObserver; };

    /* ── Utilities ──────────────────────────────────────────────────── */

    /** Normalise a field slug: strip hp_ prefix, [] suffix */
    function slug( name ) {
        return ( name || '' ).replace( /^hp_/, '' ).replace( /\[\]$/, '' );
    }

    /** Find a <select> inside a form by field slug */
    function findSelect( form, fieldSlug ) {
        var sel = form.querySelector(
            'select[name="' + fieldSlug + '"],' +
            'select[name="hp_' + fieldSlug + '"],' +
            '[data-field="' + fieldSlug + '"] select,' +
            '[data-field="hp_' + fieldSlug + '"] select'
        );
        return sel || null;
    }

    /** Get the HP listing category term ID currently selected in this form */
    function getCategoryId( form ) {
        /* HP renders the category field as a select with name "listing_category"
           or as hidden input or as data attribute on the form itself */
        var catSel = form.querySelector(
            'select[name="listing_category"],' +
            'select[name="hp_listing_category"],' +
            'select[name="_category"]'
        );
        if ( catSel && catSel.value ) { return parseInt( catSel.value, 10 ); }

        /* Hidden input (HP sometimes pre-fills category via hidden field) */
        var hidden = form.querySelector(
            'input[type="hidden"][name="listing_category"],' +
            'input[type="hidden"][name="_category"]'
        );
        if ( hidden && hidden.value ) { return parseInt( hidden.value, 10 ); }

        /* data-category on the form element itself */
        var dc = form.getAttribute( 'data-category' ) || form.getAttribute( 'data-listing-category' );
        if ( dc ) { return parseInt( dc, 10 ); }

        return 0;
    }

    /** Check if a pair should be active for a given category ID */
    function pairActiveForCategory( pairData, catId ) {
        if ( ! pairData.category_ids || ! pairData.category_ids.length ) {
            return true; // No restriction → always active
        }
        if ( ! catId ) {
            return true; // Category not known yet → show (better UX than hiding)
        }
        return pairData.category_ids.indexOf( catId ) !== -1;
    }

    /* ── Snapshot original <select> options ─────────────────────────── */

    function snapshot( el ) {
        var s = slug( el.name );
        if ( snapshots[ s ] ) { return; }
        var opts = {};
        Array.prototype.forEach.call( el.options, function ( o ) {
            if ( o.value !== '' ) { opts[ o.value ] = o.textContent.trim(); }
        } );
        if ( Object.keys( opts ).length ) {
            snapshots[ s ] = opts;
        }
    }

    /* ── Rebuild a child <select> with allowed values only ─────────── */

    /** Detect if a form is a search/filter form (not an edit/submit form) */
    function isFilterForm( form ) {
        if ( ! form ) { return false; }
        // HP filter/search forms use method GET or have data-block="listings"
        // Edit/submit forms use method POST
        var method = ( form.getAttribute( 'method' ) || '' ).toUpperCase();
        if ( method === 'GET' ) { return true; }
        if ( form.getAttribute( 'data-block' ) === 'listings' ) { return true; }
        if ( form.classList.contains( 'hp-listings__filter' ) ) { return true; }
        if ( form.classList.contains( 'hp-listing-search' ) ) { return true; }
        return false;
    }

    function rebuildSelect( el, allowedValues, form ) {
        var s        = slug( el.name );
        var orig     = snapshots[ s ] || {};
        var prevVal  = el.value;
        var isS2     = !! $( el ).data( 'select2' );
        var allowed  = null;

        if ( allowedValues ) {
            allowed = {};
            allowedValues.forEach( function ( v ) { allowed[ v ] = true; } );
        }

        /* Pause MutationObserver so our DOM changes don't re-trigger scanContainer */
        _pauseObserver = true;

        if ( isS2 ) { try { $( el ).select2( 'destroy' ); } catch (e) {} }

        /* Keep placeholder option */
        var ph = null;
        Array.prototype.forEach.call( el.options, function ( o ) {
            if ( o.value === '' ) { ph = o.cloneNode( true ); }
        } );

        el.innerHTML = '';
        if ( ph ) { el.appendChild( ph ); }

        var prevOk = false;
        Object.keys( orig ).forEach( function ( val ) {
            if ( allowed && ! allowed[ val ] ) { return; }
            var opt         = document.createElement( 'option' );
            opt.value       = val;
            opt.textContent = orig[ val ];
            if ( val === prevVal ) { opt.selected = true; prevOk = true; }
            el.appendChild( opt );
        } );

        if ( ! prevOk ) { el.value = ''; }

        if ( isS2 ) {
            try {
                $( el ).select2( {
                    width:       '100%',
                    allowClear:  true,
                    placeholder: ph ? ( ph.textContent.trim() || '' ) : '',
                } );
            } catch (e) {}
        }

        /* Resume observer after a tick */
        setTimeout( function () { _pauseObserver = false; }, 0 );

        /*
         * For cascading child→grandchild pairs on non-filter forms,
         * dispatch a NON-BUBBLING custom event so our own bindParent
         * handlers fire but HivePress's document-level listener never sees it.
         */
        if ( ! isFilterForm( form ) ) {
            var ev = document.createEvent( 'Event' );
            ev.initEvent( 'change', false, true ); // bubbles=false
            el.dispatchEvent( ev );
        }
    }

    /* ── Show / hide a field wrapper ─────────────────────────────────── */

    function setVisible( el, visible ) {
        var wrapper = el.closest( '.hp-field, .hp-field-wrapper, [class*="hp-field"]' ) || el.parentElement;
        if ( wrapper ) {
            wrapper.style.display = visible ? '' : 'none';
        }
        el.disabled = ! visible;
    }

    /* ── Core: apply conditional logic for one pair in one form ──────── */

    function applyPair( form, pairData, parentEl ) {
        var catId = getCategoryId( form );

        /* If pair is restricted to categories and current category doesn't match,
           hide both fields */
        var active = pairActiveForCategory( pairData, catId );

        var childEl = findSelect( form, pairData.child_field );
        if ( ! childEl ) { return; }

        if ( ! active ) {
            setVisible( parentEl, false );
            setVisible( childEl,  false );
            return;
        }

        setVisible( parentEl, true );
        setVisible( childEl,  true );

        var parentValue = parentEl.value;

        if ( ! parentValue ) {
            rebuildSelect( childEl, null, form );
            return;
        }

        var rules   = pairData.rules || {};
        var allowed = rules[ parentValue ] || null;
        rebuildSelect( childEl, allowed, form );
    }

    /* ── Bind a parent select inside a form ──────────────────────────── */

    function bindParent( form, pairData, parentEl ) {
        if ( parentEl._hpcdBound ) { return; }
        parentEl._hpcdBound = true;

        /* Snapshot child before first manipulation */
        var childEl = findSelect( form, pairData.child_field );
        if ( childEl ) { snapshot( childEl ); }

        var handler = function ( e ) {
            /*
             * CRITICAL: Stop the change event from bubbling up to the form.
             * HivePress listens at the form/document level for select changes
             * and submits the filter when it hears one — causing a page reload
             * loop when results are found and the listings block re-renders.
             * We handle the cascade ourselves so propagation is not needed.
             */
            if ( e && e.stopPropagation ) { e.stopPropagation(); }
            applyPair( form, pairData, parentEl );
        };

        parentEl.addEventListener( 'change', handler );
        $( parentEl ).on( 'select2:select select2:unselect select2:clear', handler );

        /* Apply immediately if value is already set */
        if ( parentEl.value ) {
            setTimeout( handler, 50 );
        }
    }

    /* ── Bind category select in a form ─────────────────────────────── */

    function bindCategory( form ) {
        if ( form._hpcdCatBound ) { return; }
        form._hpcdCatBound = true;

        var catSel = form.querySelector(
            'select[name="listing_category"], select[name="hp_listing_category"], select[name="_category"]'
        );
        if ( ! catSel ) { return; }

        var refresh = function () {
            Object.keys( DATA ).forEach( function ( pSlug ) {
                var pd       = DATA[ pSlug ];
                var parentEl = findSelect( form, pd.parent_field );
                if ( parentEl ) { applyPair( form, pd, parentEl ); }
            } );
        };

        catSel.addEventListener( 'change', refresh );
        $( catSel ).on( 'select2:select select2:unselect', refresh );
    }

    /* ── Scan a container for HP forms ─────────────────────────────── */

    function scanContainer( root ) {
        /* HP forms have class hp-form or are <form> elements */
        var forms = root.querySelectorAll( 'form.hp-form, form[class*="hp-"]' );
        if ( ! forms.length ) {
            /* Fallback: any form on page */
            forms = root.querySelectorAll( 'form' );
        }

        Array.prototype.forEach.call( forms, function ( form ) {
            bindCategory( form );

            Object.keys( DATA ).forEach( function ( pSlug ) {
                var pd       = DATA[ pSlug ];
                var parentEl = findSelect( form, pd.parent_field );
                if ( ! parentEl ) { return; }
                snapshot( parentEl );
                bindParent( form, pd, parentEl );
            } );
        } );
    }

    /* ── MutationObserver (HP renders forms dynamically) ─────────────── */

    function setupObserver() {
        if ( ! window.MutationObserver ) { return; }
        var obs = new MutationObserver( function ( mutations ) {
            if ( _pauseObserver ) { return; }
            var dirty = false;
            mutations.forEach( function ( m ) {
                m.addedNodes.forEach( function ( n ) {
                    if ( n.nodeType !== 1 ) { return; }
                    if ( n.tagName === 'FORM' || n.querySelector( 'form' ) ) { dirty = true; }
                } );
            } );
            if ( dirty ) { setTimeout( function () { scanContainer( document ); }, 150 ); }
        } );
        obs.observe( document.body, { childList: true, subtree: true } );
    }

    /* ── Boot ────────────────────────────────────────────────────────── */

    function boot() {
        setTimeout( function () {
            scanContainer( document );
            setupObserver();
        }, 300 );

        /* HP fires this when a form block is re-rendered */
        $( document ).on( 'hp_block_render hp_form_update', function () {
            setTimeout( function () { scanContainer( document ); }, 150 );
        } );
    }

    if ( document.readyState === 'loading' ) {
        document.addEventListener( 'DOMContentLoaded', boot );
    } else {
        boot();
    }

} )( window.jQuery || { fn: {}, on: function(){}, trigger: function(){} } );

/* ── Attribute display rewrite (icon + format) ──────────────────────────
 *
 * HP renders our attributes as plain text:
 *   <div class="hp-listing__attribute hp-listing__attribute--make">BYD</div>
 *
 * We rewrite them client-side using the icon/format data from hpcdData,
 * replacing %icon%, %label%, %value% tokens — same logic as HP's own
 * display format system but executed in JS to avoid server-side conflicts.
 */
( function () {
    var DATA = window.hpcdData || {};

    function applyDisplayFormat( root ) {
        root = root || document;

        Object.keys( DATA ).forEach( function ( parentSlug ) {
            var pair = DATA[ parentSlug ];

            // Process both parent and child fields
            [
                { slug: pair.parent_field, icon: pair.parent_icon, label: pair.parent_label, format: pair.parent_format },
                { slug: pair.child_field,  icon: pair.child_icon,  label: pair.child_label,  format: pair.child_format  }
            ].forEach( function ( field ) {
                if ( ! field.slug ) { return; }

                // Skip if no icon and default format (nothing to change)
                var hasIcon   = field.icon && field.icon.length > 0;
                var hasFormat = field.format && field.format !== '%icon% %label%: %value%';
                if ( ! hasIcon && ! hasFormat ) { return; }

                var cls  = 'hp-listing__attribute--' + field.slug;
                var els  = root.querySelectorAll( '.' + cls );

                Array.prototype.forEach.call( els, function ( el ) {
                    // Only rewrite if content is still plain text (not already rewritten)
                    if ( el.querySelector( 'i.hp-icon' ) ) { return; }

                    var rawValue = el.textContent.trim();
                    if ( ! rawValue ) { return; }

                    var fmt = field.format || '%icon% %label%: %value%';
                    var out = fmt
                        .replace( '%icon%',  field.icon  || '' )
                        .replace( '%label%', escHtml( field.label || '' ) )
                        .replace( '%value%', escHtml( rawValue ) );

                    el.innerHTML = out;
                } );
            } );
        } );
    }

    function escHtml( str ) {
        return str
            .replace( /&/g, '&amp;' )
            .replace( /</g, '&lt;' )
            .replace( />/g, '&gt;' )
            .replace( /"/g, '&quot;' );
    }

    // Run on DOM ready
    if ( document.readyState === 'loading' ) {
        document.addEventListener( 'DOMContentLoaded', function () {
            applyDisplayFormat();
            setupDisplayObserver();
        } );
    } else {
        applyDisplayFormat();
        setupDisplayObserver();
    }

    function setupDisplayObserver() {
        var $ = window.jQuery;

        // Re-run when HP re-renders listing blocks (AJAX filter results)
        if ( $ ) {
            $( document ).on( 'hp_block_render hp_listing_update hp_listings_render', function () {
                setTimeout( function () { applyDisplayFormat( document ); }, 150 );
            } );
        }

        // MutationObserver for AJAX-loaded listing blocks
        if ( ! window.MutationObserver ) { return; }
        var obs = new MutationObserver( function ( mutations ) {
            // Don't run while our own rebuildSelect is manipulating the DOM
            if ( window._hpcdPauseObserver && window._hpcdPauseObserver() ) { return; }
            var needsReformat = false;
            mutations.forEach( function ( m ) {
                m.addedNodes.forEach( function ( node ) {
                    if ( node.nodeType !== 1 ) { return; }
                    if ( node.classList && node.classList.contains( 'hp-listing__attribute' ) ) {
                        needsReformat = true;
                    } else if ( node.querySelector && node.querySelector( '.hp-listing__attribute' ) ) {
                        needsReformat = true;
                    }
                } );
            } );
            if ( needsReformat ) {
                setTimeout( function () { applyDisplayFormat( document ); }, 100 );
            }
        } );
        obs.observe( document.body, { childList: true, subtree: true } );
    }

} )();
