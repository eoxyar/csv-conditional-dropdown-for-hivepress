<?php
/**
 * Plugin Name: HivePress Conditional Dropdowns
 * Plugin URI:  https://example.com
 * Description: Conditional (dependent) select field pairs for HivePress — add listing, edit, search and filter forms. Category-restricted.
 * Version: 1.0.18
 * Author:      Your Name
 * Text Domain: hp-conditional-dropdowns
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

defined( 'ABSPATH' ) || exit;

define( 'HPCD_VERSION', '2.0.0' );
define( 'HPCD_FILE',    __FILE__ );
define( 'HPCD_DIR',     plugin_dir_path( __FILE__ ) );
define( 'HPCD_URL',     plugin_dir_url( __FILE__ ) );

/* DB must be available immediately for activation hook */
require_once HPCD_DIR . 'includes/class-db.php';

register_activation_hook( __FILE__, array( 'HPCD_DB', 'install' ) );
register_uninstall_hook( __FILE__,  array( 'HPCD_DB', 'uninstall' ) );

add_action( 'plugins_loaded', 'hpcd_boot', 20 );

function hpcd_boot() {
    /* Ensure DB table exists even if plugin was copied without activation */
    if ( get_option( HPCD_DB::VER_OPTION ) !== HPCD_DB::VER ) {
        HPCD_DB::install();
    }

    if ( ! class_exists( 'HivePress\Core' ) ) {
        add_action( 'admin_notices', function () {
            echo '<div class="notice notice-error"><p>'
                . esc_html__( 'HivePress Conditional Dropdowns requires HivePress to be installed and active.', 'hp-conditional-dropdowns' )
                . '</p></div>';
        } );
        return;
    }

    require_once HPCD_DIR . 'includes/class-fields.php';
    require_once HPCD_DIR . 'includes/class-scripts.php';
    require_once HPCD_DIR . 'includes/class-admin.php';
    require_once HPCD_DIR . 'includes/class-ajax.php';

    HPCD_Fields::init();
    HPCD_Scripts::init();
    HPCD_Admin::init();
    HPCD_Ajax::init();
}
