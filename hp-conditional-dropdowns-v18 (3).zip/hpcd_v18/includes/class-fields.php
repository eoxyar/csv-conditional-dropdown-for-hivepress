<?php
defined( 'ABSPATH' ) || exit;

class HPCD_Fields {

    public static function init() {
        add_filter( 'hivepress/v1/models/listing/attributes', array( __CLASS__, 'add_listing_attributes' ), 1000 );
        // NOTE: Icon/format display is handled client-side via JS (conditional.js)
        // to avoid interfering with HivePress filter/redirect logic.
    }

    /* ── Helpers ─────────────────────────────────────────────────────── */

    /** Returns bare icon name, e.g. "car" from "fas fa-car" or "fa-car" or "car" */
    public static function bare_icon( $icon ) {
        if ( empty( $icon ) ) { return ''; }
        $icon = trim( $icon );
        $icon = preg_replace( '/^fa[srbldi]?\s+fa-/', '', $icon );
        $icon = preg_replace( '/^fa-/', '', $icon );
        return $icon;
    }

    public static function get_category_ids( $pair ) {
        if ( empty( $pair->category_ids ) ) { return array(); }
        return array_values( array_filter( array_map( 'intval', explode( ',', $pair->category_ids ) ) ) );
    }

    public static function get_data_map( $pair_id ) {
        return HPCD_DB::get_data_map( $pair_id );
    }

    /* ── Attributes filter ───────────────────────────────────────────── */

    public static function add_listing_attributes( $attributes ) {
        $pairs = HPCD_DB::get_pairs( true );
        if ( empty( $pairs ) ) { return $attributes; }

        $our = array();

        foreach ( $pairs as $idx => $pair ) {
            $data_map     = self::get_data_map( $pair->id );
            $category_ids = self::get_category_ids( $pair );

            $p_ord = 20 + $idx * 10;
            $c_ord = 20 + $idx * 10 + 1;

            $parent_options = array( '' => __( 'Please select', 'hp-conditional-dropdowns' ) . ' ' . $pair->parent_field_label );
            foreach ( array_keys( $data_map ) as $pv ) { $parent_options[ $pv ] = $pv; }

            $child_options = array( '' => __( 'Please select', 'hp-conditional-dropdowns' ) . ' ' . $pair->child_field_label );
            foreach ( $data_map as $children ) {
                foreach ( array_keys( $children ) as $cv ) { $child_options[ $cv ] = $cv; }
            }

            $display_areas = array();
            if ( ! empty( $pair->block_display ) && 'hide' !== $pair->block_display ) {
                $display_areas[] = 'view_block_' . $pair->block_display;
            }
            if ( ! empty( $pair->page_display ) && 'hide' !== $pair->page_display ) {
                $display_areas[] = 'view_page_' . $pair->page_display;
            }

            $parent = array(
                'label'         => $pair->parent_field_label,
                'editable'      => true,
                'filterable'    => (bool) $pair->filter_enabled,
                'searchable'    => (bool) $pair->search_enabled,
                'indexable'     => true,
                'display_areas' => $display_areas,
                'edit_field'    => array(
                    'label'     => $pair->parent_field_label,
                    'type'      => 'select',
                    'options'   => $parent_options,
                    '_external' => true,
                    '_order'    => $p_ord,
                    'required'  => false,
                ),
                'search_field'  => array(
                    'label'     => $pair->parent_field_label,
                    'type'      => 'select',
                    'options'   => $parent_options,
                    '_external' => true,
                    '_order'    => $p_ord,
                ),
            );
            if ( ! empty( $category_ids ) ) { $parent['categories'] = $category_ids; }

            $child = array(
                'label'         => $pair->child_field_label,
                'editable'      => true,
                'filterable'    => (bool) $pair->filter_enabled,
                'searchable'    => (bool) $pair->search_enabled,
                'indexable'     => true,
                'display_areas' => $display_areas,
                'edit_field'    => array(
                    'label'     => $pair->child_field_label,
                    'type'      => 'select',
                    'options'   => $child_options,
                    '_external' => true,
                    '_order'    => $c_ord,
                    'required'  => false,
                ),
                'search_field'  => array(
                    'label'     => $pair->child_field_label,
                    'type'      => 'select',
                    'options'   => $child_options,
                    '_external' => true,
                    '_order'    => $c_ord,
                ),
            );
            if ( ! empty( $category_ids ) ) { $child['categories'] = $category_ids; }

            $our[ $pair->parent_field_name ] = $parent;
            $our[ $pair->child_field_name  ] = $child;
        }

        foreach ( $attributes as $slug => $def ) {
            if ( ! isset( $our[ $slug ] ) ) { $our[ $slug ] = $def; }
        }

        return $our;
    }
}
