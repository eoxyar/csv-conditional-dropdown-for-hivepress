<?php
defined( 'ABSPATH' ) || exit;

class HPCD_DB {

    const VER_OPTION = 'hpcd_db_version';
    const VER        = '2.1.0';

    public static function install() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset = $wpdb->get_charset_collate();

        dbDelta( "CREATE TABLE {$wpdb->prefix}hpcd_field_pairs (
            id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            pair_name           VARCHAR(191)    NOT NULL DEFAULT '',
            parent_field_name   VARCHAR(100)    NOT NULL DEFAULT '',
            parent_field_label  VARCHAR(191)    NOT NULL DEFAULT '',
            parent_icon         VARCHAR(100)    NOT NULL DEFAULT '',
            parent_format       VARCHAR(255)    NOT NULL DEFAULT '%icon% %label%: %value%',
            child_field_name    VARCHAR(100)    NOT NULL DEFAULT '',
            child_field_label   VARCHAR(191)    NOT NULL DEFAULT '',
            child_icon          VARCHAR(100)    NOT NULL DEFAULT '',
            child_format        VARCHAR(255)    NOT NULL DEFAULT '%icon% %label%: %value%',
            category_ids        TEXT            NOT NULL DEFAULT '',
            search_enabled      TINYINT(1)      NOT NULL DEFAULT 1,
            filter_enabled      TINYINT(1)      NOT NULL DEFAULT 1,
            block_display       VARCHAR(50)     NOT NULL DEFAULT 'secondary',
            page_display        VARCHAR(50)     NOT NULL DEFAULT 'secondary',
            sort_order          INT             NOT NULL DEFAULT 0,
            status              TINYINT(1)      NOT NULL DEFAULT 1,
            created_at          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset;" );

        dbDelta( "CREATE TABLE {$wpdb->prefix}hpcd_conditional_data (
            id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            pair_id      BIGINT UNSIGNED NOT NULL,
            parent_value VARCHAR(191)    NOT NULL DEFAULT '',
            child_value  VARCHAR(191)    NOT NULL DEFAULT '',
            sort_order   INT             NOT NULL DEFAULT 0,
            PRIMARY KEY  (id),
            KEY pair_parent (pair_id, parent_value(100))
        ) $charset;" );

        update_option( self::VER_OPTION, self::VER );
    }

    public static function uninstall() {
        global $wpdb;
        $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}hpcd_conditional_data" );
        $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}hpcd_field_pairs" );
        delete_option( self::VER_OPTION );
    }

    /* ── Pairs ─────────────────────────────────────────────────────────── */

    public static function get_pairs( $active_only = true ) {
        global $wpdb;
        $where = $active_only ? 'WHERE status = 1' : '';
        return $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}hpcd_field_pairs $where ORDER BY sort_order ASC, id ASC" );
    }

    public static function get_pair( $id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}hpcd_field_pairs WHERE id = %d", $id ) );
    }

    public static function insert_pair( $data ) {
        global $wpdb;
        $wpdb->insert( $wpdb->prefix . 'hpcd_field_pairs', $data );
        return $wpdb->insert_id;
    }

    public static function update_pair( $id, $data ) {
        global $wpdb;
        $wpdb->update( $wpdb->prefix . 'hpcd_field_pairs', $data, array( 'id' => $id ) );
    }

    public static function delete_pair( $id ) {
        global $wpdb;
        $wpdb->delete( $wpdb->prefix . 'hpcd_conditional_data', array( 'pair_id' => $id ) );
        $wpdb->delete( $wpdb->prefix . 'hpcd_field_pairs',      array( 'id'      => $id ) );
    }

    /* ── Conditional data ───────────────────────────────────────────────── */

    public static function get_data( $pair_id, $search = '', $limit = 200, $offset = 0 ) {
        global $wpdb;
        $where = $wpdb->prepare( 'WHERE pair_id = %d', $pair_id );
        if ( $search ) {
            $like   = '%' . $wpdb->esc_like( $search ) . '%';
            $where .= $wpdb->prepare( ' AND (parent_value LIKE %s OR child_value LIKE %s)', $like, $like );
        }
        return $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}hpcd_conditional_data $where ORDER BY parent_value ASC, sort_order ASC, child_value ASC LIMIT $offset, $limit" );
    }

    public static function count_data( $pair_id, $search = '' ) {
        global $wpdb;
        $where = $wpdb->prepare( 'WHERE pair_id = %d', $pair_id );
        if ( $search ) {
            $like   = '%' . $wpdb->esc_like( $search ) . '%';
            $where .= $wpdb->prepare( ' AND (parent_value LIKE %s OR child_value LIKE %s)', $like, $like );
        }
        return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}hpcd_conditional_data $where" );
    }

    public static function get_data_map( $pair_id ) {
        global $wpdb;
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT parent_value, child_value FROM {$wpdb->prefix}hpcd_conditional_data WHERE pair_id = %d ORDER BY parent_value ASC, sort_order ASC, child_value ASC",
            $pair_id
        ) );
        $map = array();
        foreach ( $rows as $r ) {
            $map[ $r->parent_value ][ $r->child_value ] = true;
        }
        return $map;
    }

    public static function get_parent_values( $pair_id ) {
        global $wpdb;
        return $wpdb->get_col( $wpdb->prepare(
            "SELECT DISTINCT parent_value FROM {$wpdb->prefix}hpcd_conditional_data WHERE pair_id = %d ORDER BY parent_value ASC",
            $pair_id
        ) );
    }

    public static function get_child_values( $pair_id, $parent_value ) {
        global $wpdb;
        return $wpdb->get_col( $wpdb->prepare(
            "SELECT DISTINCT child_value FROM {$wpdb->prefix}hpcd_conditional_data WHERE pair_id = %d AND parent_value = %s ORDER BY sort_order ASC, child_value ASC",
            $pair_id, $parent_value
        ) );
    }

    public static function insert_data_row( $pair_id, $parent_value, $child_value, $sort_order = 0 ) {
        global $wpdb;
        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}hpcd_conditional_data WHERE pair_id=%d AND parent_value=%s AND child_value=%s",
            $pair_id, $parent_value, $child_value
        ) );
        if ( $exists ) { return false; }
        $wpdb->insert( $wpdb->prefix . 'hpcd_conditional_data', array(
            'pair_id'      => $pair_id,
            'parent_value' => $parent_value,
            'child_value'  => $child_value,
            'sort_order'   => $sort_order,
        ) );
        return $wpdb->insert_id;
    }

    public static function delete_data_row( $id ) {
        global $wpdb;
        $wpdb->delete( $wpdb->prefix . 'hpcd_conditional_data', array( 'id' => $id ) );
    }

    public static function delete_data_for_pair( $pair_id ) {
        global $wpdb;
        $wpdb->delete( $wpdb->prefix . 'hpcd_conditional_data', array( 'pair_id' => $pair_id ) );
    }
}
