/**
 * HivePress Conditional Dropdowns — Frontend  v2.0.0
 *
 * hpcdData structure (injected inline by PHP):
 * {
 *   "make": {
 *     id: 1,
 *     parent_field: "make",
 *     child_field: "model",
 *     rules: { "Toyota": ["Corolla","Camry"], "Honda": ["Civic","Accord"] },
 *     category_ids: [12, 15]   ← [] = all categories
 *   }
 * }
 *
 * Category filtering strategy:
 *   - If category_ids is empty → pair is active on ALL categories.
 *   - If category_ids has entries → pair is only active when the current
 *     listing category (read from the category field in the same form)
 *     matches one of the IDs.
 *   - We watch the category field for changes and re-evaluate visibility.
 */
( function ( $ ) {
    'use strict';

    var DATA = window.hpcdData || {};
    if ( ! Object.keys( DATA ).length ) { return; }

    /* ── Option snapshots (slug → {val: label}) ────────────────────── */
    var snapshots = {};

    /* ── Utilities ──────────────────────────────────────────────────── */

    /** Normalise a field slug: strip hp_ prefix, [] suffix */
    function slug( name ) {
        return ( name || '' ).replace( /^hp_/, '' ).replace( /\[\]$/, '' );
    }

    /** Find a <select> inside a form by field slug */
    function findSelect( form, fieldSlug ) {
        var sel = form.querySelector(
            'select[name="' + fieldSlug + '"],' +
            'select[name="hp_' + fieldSlug + '"],' +
            '[data-field="' + fieldSlug + '"] select,' +
            '[data-field="hp_' + fieldSlug + '"] select'
        );
        return sel || null;
    }

    /** Get the HP listing category term ID currently selected in this form */
    function getCategoryId( form ) {
        /* HP renders the category field as a select with name "listing_category"
           or as hidden input or as data attribute on the form itself */
        var catSel = form.querySelector(
            'select[name="listing_category"],' +
            'select[name="hp_listing_category"],' +
            'select[name="_category"]'
        );
        if ( catSel && catSel.value ) { return parseInt( catSel.value, 10 ); }

        /* Hidden input (HP sometimes pre-fills category via hidden field) */
        var hidden = form.querySelector(
            'input[type="hidden"][name="listing_category"],' +
            'input[type="hidden"][name="_category"]'
        );
        if ( hidden && hidden.value ) { return parseInt( hidden.value, 10 ); }

        /* data-category on the form element itself */
        var dc = form.getAttribute( 'data-category' ) || form.getAttribute( 'data-listing-category' );
        if ( dc ) { return parseInt( dc, 10 ); }

        return 0;
    }

    /** Check if a pair should be active for a given category ID */
    function pairActiveForCategory( pairData, catId ) {
        if ( ! pairData.category_ids || ! pairData.category_ids.length ) {
            return true; // No restriction → always active
        }
        if ( ! catId ) {
            return true; // Category not known yet → show (better UX than hiding)
        }
        return pairData.category_ids.indexOf( catId ) !== -1;
    }

    /* ── Snapshot original <select> options ─────────────────────────── */

    function snapshot( el ) {
        var s = slug( el.name );
        if ( snapshots[ s ] ) { return; }
        var opts = {};
        Array.prototype.forEach.call( el.options, function ( o ) {
            if ( o.value !== '' ) { opts[ o.value ] = o.textContent.trim(); }
        } );
        if ( Object.keys( opts ).length ) {
            snapshots[ s ] = opts;
        }
    }

    /* ── Rebuild a child <select> with allowed values only ─────────── */

    function rebuildSelect( el, allowedValues ) {
        var s        = slug( el.name );
        var orig     = snapshots[ s ] || {};
        var prevVal  = el.value;
        var isS2     = !! $( el ).data( 'select2' );
        var allowed  = null;

        if ( allowedValues ) {
            allowed = {};
            allowedValues.forEach( function ( v ) { allowed[ v ] = true; } );
        }

        if ( isS2 ) { try { $( el ).select2( 'destroy' ); } catch (e) {} }

        /* Keep placeholder option */
        var ph = null;
        Array.prototype.forEach.call( el.options, function ( o ) {
            if ( o.value === '' ) { ph = o.cloneNode( true ); }
        } );

        el.innerHTML = '';
        if ( ph ) { el.appendChild( ph ); }

        var prevOk = false;
        Object.keys( orig ).forEach( function ( val ) {
            if ( allowed && ! allowed[ val ] ) { return; }
            var opt       = document.createElement( 'option' );
            opt.value     = val;
            opt.textContent = orig[ val ];
            if ( val === prevVal ) { opt.selected = true; prevOk = true; }
            el.appendChild( opt );
        } );

        if ( ! prevOk ) { el.value = ''; }

        if ( isS2 ) {
            try {
                $( el ).select2( {
                    width:       '100%',
                    allowClear:  true,
                    placeholder: ph ? ( ph.textContent.trim() || '' ) : '',
                } );
            } catch (e) {}
        }

        /* Fire change so cascaded pairs trigger */
        $( el ).trigger( 'change' );
    }

    /* ── Show / hide a field wrapper ─────────────────────────────────── */

    function setVisible( el, visible ) {
        var wrapper = el.closest( '.hp-field, .hp-field-wrapper, [class*="hp-field"]' ) || el.parentElement;
        if ( wrapper ) {
            wrapper.style.display = visible ? '' : 'none';
        }
        el.disabled = ! visible;
    }

    /* ── Core: apply conditional logic for one pair in one form ──────── */

    function applyPair( form, pairData, parentEl ) {
        var catId = getCategoryId( form );

        /* If pair is restricted to categories and current category doesn't match,
           hide both fields */
        var active = pairActiveForCategory( pairData, catId );

        var childEl = findSelect( form, pairData.child_field );
        if ( ! childEl ) { return; }

        if ( ! active ) {
            setVisible( parentEl, false );
            setVisible( childEl,  false );
            return;
        }

        setVisible( parentEl, true );
        setVisible( childEl,  true );

        var parentValue = parentEl.value;

        if ( ! parentValue ) {
            rebuildSelect( childEl, null );
            return;
        }

        var rules   = pairData.rules || {};
        var allowed = rules[ parentValue ] || null;
        rebuildSelect( childEl, allowed );
    }

    /* ── Bind a parent select inside a form ──────────────────────────── */

    function bindParent( form, pairData, parentEl ) {
        if ( parentEl._hpcdBound ) { return; }
        parentEl._hpcdBound = true;

        /* Snapshot child before first manipulation */
        var childEl = findSelect( form, pairData.child_field );
        if ( childEl ) { snapshot( childEl ); }

        var handler = function () { applyPair( form, pairData, parentEl ); };

        parentEl.addEventListener( 'change', handler );
        $( parentEl ).on( 'select2:select select2:unselect select2:clear', handler );

        /* Apply immediately if value is already set */
        if ( parentEl.value ) {
            setTimeout( handler, 50 );
        }
    }

    /* ── Bind category select in a form ─────────────────────────────── */

    function bindCategory( form ) {
        if ( form._hpcdCatBound ) { return; }
        form._hpcdCatBound = true;

        var catSel = form.querySelector(
            'select[name="listing_category"], select[name="hp_listing_category"], select[name="_category"]'
        );
        if ( ! catSel ) { return; }

        var refresh = function () {
            Object.keys( DATA ).forEach( function ( pSlug ) {
                var pd       = DATA[ pSlug ];
                var parentEl = findSelect( form, pd.parent_field );
                if ( parentEl ) { applyPair( form, pd, parentEl ); }
            } );
        };

        catSel.addEventListener( 'change', refresh );
        $( catSel ).on( 'select2:select select2:unselect', refresh );
    }

    /* ── Scan a container for HP forms ─────────────────────────────── */

    function scanContainer( root ) {
        /* HP forms have class hp-form or are <form> elements */
        var forms = root.querySelectorAll( 'form.hp-form, form[class*="hp-"]' );
        if ( ! forms.length ) {
            /* Fallback: any form on page */
            forms = root.querySelectorAll( 'form' );
        }

        Array.prototype.forEach.call( forms, function ( form ) {
            bindCategory( form );

            Object.keys( DATA ).forEach( function ( pSlug ) {
                var pd       = DATA[ pSlug ];
                var parentEl = findSelect( form, pd.parent_field );
                if ( ! parentEl ) { return; }
                snapshot( parentEl );
                bindParent( form, pd, parentEl );
            } );
        } );
    }

    /* ── MutationObserver (HP renders forms dynamically) ─────────────── */

    function setupObserver() {
        if ( ! window.MutationObserver ) { return; }
        var obs = new MutationObserver( function ( mutations ) {
            var dirty = false;
            mutations.forEach( function ( m ) {
                m.addedNodes.forEach( function ( n ) {
                    if ( n.nodeType !== 1 ) { return; }
                    if ( n.tagName === 'FORM' || n.querySelector( 'form' ) ) { dirty = true; }
                } );
            } );
            if ( dirty ) { setTimeout( function () { scanContainer( document ); }, 150 ); }
        } );
        obs.observe( document.body, { childList: true, subtree: true } );
    }

    /* ── Boot ────────────────────────────────────────────────────────── */

    function boot() {
        setTimeout( function () {
            scanContainer( document );
            setupObserver();
        }, 300 );

        /* HP fires this when a form block is re-rendered */
        $( document ).on( 'hp_block_render hp_form_update', function () {
            setTimeout( function () { scanContainer( document ); }, 150 );
        } );
    }

    if ( document.readyState === 'loading' ) {
        document.addEventListener( 'DOMContentLoaded', boot );
    } else {
        boot();
    }

} )( window.jQuery || { fn: {}, on: function(){}, trigger: function(){} } );
