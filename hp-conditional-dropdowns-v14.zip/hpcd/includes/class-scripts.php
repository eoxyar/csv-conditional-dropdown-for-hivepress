<?php
defined( 'ABSPATH' ) || exit;

class HPCD_Scripts {

    public static function init() {
        add_action( 'wp_enqueue_scripts',    array( __CLASS__, 'frontend' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'admin_listing' ) );
    }

    /* ── Build the inline JS data object ────────────────────────────── */

    private static function build_inline_data() {
        $pairs = HPCD_DB::get_pairs( true );
        $out   = array();

        foreach ( $pairs as $pair ) {
            $map          = HPCD_DB::get_data_map( $pair->id );
            $category_ids = HPCD_Fields::get_category_ids( $pair );

            /*
             * Restructure map to: { parent_value: [child_value, ...] }
             * JS only needs an array of allowed children per parent value.
             */
            $rules = array();
            foreach ( $map as $pv => $children ) {
                $rules[ $pv ] = array_values( array_keys( $children ) );
            }

            $out[ $pair->parent_field_name ] = array(
                'id'           => intval( $pair->id ),
                'parent_field' => $pair->parent_field_name,
                'child_field'  => $pair->child_field_name,
                'rules'        => $rules,
                'category_ids' => $category_ids,   // [] = all categories
            );
        }

        return $out;
    }

    /* ── Frontend ────────────────────────────────────────────────────── */

    public static function frontend() {
        wp_enqueue_script(
            'hpcd-conditional',
            HPCD_URL . 'assets/js/conditional.js',
            array( 'jquery' ),
            HPCD_VERSION,
            true
        );

        wp_add_inline_script(
            'hpcd-conditional',
            'window.hpcdData = ' . wp_json_encode( self::build_inline_data() ) . ';',
            'before'
        );

        wp_enqueue_style( 'hpcd-frontend', HPCD_URL . 'assets/css/frontend.css', array(), HPCD_VERSION );
    }

    /* ── Admin listing edit page ─────────────────────────────────────── */

    public static function admin_listing( $hook ) {
        global $post_type;

        if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
            return;
        }
        if ( $post_type !== 'hp_listing' ) {
            return;
        }

        wp_enqueue_script(
            'hpcd-conditional',
            HPCD_URL . 'assets/js/conditional.js',
            array( 'jquery' ),
            HPCD_VERSION,
            true
        );

        wp_add_inline_script(
            'hpcd-conditional',
            'window.hpcdData = ' . wp_json_encode( self::build_inline_data() ) . ';',
            'before'
        );
    }
}
