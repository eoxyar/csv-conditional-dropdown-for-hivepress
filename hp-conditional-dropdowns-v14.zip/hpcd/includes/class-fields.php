<?php
defined( 'ABSPATH' ) || exit;

class HPCD_Fields {

    public static function init() {
        add_filter( 'hivepress/v1/models/listing/attributes', array( __CLASS__, 'add_listing_attributes' ), 1000 );
        add_action( 'template_redirect', array( __CLASS__, 'start_output_buffer' ) );
    }

    /* ── Output buffer — DOM-based rewrite ───────────────────────────── */

    public static function start_output_buffer() {
        ob_start( array( __CLASS__, 'rewrite_attribute_html' ) );
    }

    public static function rewrite_attribute_html( $html ) {
        $pairs = HPCD_DB::get_pairs( true );
        if ( empty( $pairs ) ) { return $html; }

        // Build map: slug → [icon_html, label, format]
        $rewrites = array();
        foreach ( $pairs as $pair ) {
            foreach ( array( 'parent', 'child' ) as $role ) {
                $slug   = 'parent' === $role ? $pair->parent_field_name  : $pair->child_field_name;
                $label  = 'parent' === $role ? $pair->parent_field_label : $pair->child_field_label;
                $icon   = 'parent' === $role ? $pair->parent_icon        : $pair->child_icon;
                $format = 'parent' === $role ? $pair->parent_format      : $pair->child_format;

                if ( empty( $icon ) && empty( $format ) ) { continue; }

                $format    = $format ?: '%icon% %label%: %value%';
                $bare      = self::bare_icon( $icon );
                $icon_html = $bare ? '<i class="hp-icon fas fa-fw fa-' . esc_attr( $bare ) . '"></i>' : '';

                $rewrites[ $slug ] = array(
                    'icon_html' => $icon_html,
                    'label'     => $label,
                    'format'    => $format,
                );
            }
        }

        if ( empty( $rewrites ) ) { return $html; }

        /*
         * Use a simple targeted regex that matches ONLY the shallow attribute div.
         * HP renders these as single-line divs with no child elements:
         *   <div class="hp-listing__attribute hp-listing__attribute--make">BYD</div>
         *
         * Key: the content between the tags contains NO '<' characters (it's plain text).
         * This is much safer than trying to match nested HTML.
         */
        foreach ( $rewrites as $slug => $data ) {
            $pattern = '/(<div[^>]*\bhp-listing__attribute--' . preg_quote( $slug, '/' ) . '\b[^>]*>)([^<]+)(<\/div>)/';

            $html = preg_replace_callback(
                $pattern,
                function ( $m ) use ( $data ) {
                    $value = trim( $m[2] );
                    if ( '' === $value ) { return $m[0]; }

                    $formatted = str_replace(
                        array( '%icon%', '%label%', '%value%' ),
                        array( $data['icon_html'], esc_html( $data['label'] ), esc_html( $value ) ),
                        $data['format']
                    );

                    return $m[1] . $formatted . $m[3];
                },
                $html
            );
        }

        return $html;
    }

    /* ── Helpers ─────────────────────────────────────────────────────── */

    public static function bare_icon( $icon ) {
        if ( empty( $icon ) ) { return ''; }
        $icon = trim( $icon );
        $icon = preg_replace( '/^fa[srbldi]?\s+fa-/', '', $icon );
        $icon = preg_replace( '/^fa-/', '', $icon );
        return $icon;
    }

    public static function get_category_ids( $pair ) {
        if ( empty( $pair->category_ids ) ) { return array(); }
        return array_values( array_filter( array_map( 'intval', explode( ',', $pair->category_ids ) ) ) );
    }

    public static function get_data_map( $pair_id ) {
        return HPCD_DB::get_data_map( $pair_id );
    }

    /* ── Attributes filter ───────────────────────────────────────────── */

    public static function add_listing_attributes( $attributes ) {
        $pairs = HPCD_DB::get_pairs( true );
        if ( empty( $pairs ) ) { return $attributes; }

        $our = array();

        foreach ( $pairs as $idx => $pair ) {
            $data_map     = self::get_data_map( $pair->id );
            $category_ids = self::get_category_ids( $pair );

            $p_ord = 20 + $idx * 10;
            $c_ord = 20 + $idx * 10 + 1;

            $parent_options = array( '' => __( 'Please select', 'hp-conditional-dropdowns' ) . ' ' . $pair->parent_field_label );
            foreach ( array_keys( $data_map ) as $pv ) { $parent_options[ $pv ] = $pv; }

            $child_options = array( '' => __( 'Please select', 'hp-conditional-dropdowns' ) . ' ' . $pair->child_field_label );
            foreach ( $data_map as $children ) {
                foreach ( array_keys( $children ) as $cv ) { $child_options[ $cv ] = $cv; }
            }

            $display_areas = array();
            if ( ! empty( $pair->block_display ) && 'hide' !== $pair->block_display ) {
                $display_areas[] = 'view_block_' . $pair->block_display;
            }
            if ( ! empty( $pair->page_display ) && 'hide' !== $pair->page_display ) {
                $display_areas[] = 'view_page_' . $pair->page_display;
            }

            $p_bare   = self::bare_icon( $pair->parent_icon );
            $c_bare   = self::bare_icon( $pair->child_icon );
            $p_format = ! empty( $pair->parent_format ) ? $pair->parent_format : '%icon% %label%: %value%';
            $c_format = ! empty( $pair->child_format )  ? $pair->child_format  : '%icon% %label%: %value%';

            $parent = array(
                'label'         => $pair->parent_field_label,
                'editable'      => true,
                'filterable'    => (bool) $pair->filter_enabled,
                'searchable'    => (bool) $pair->search_enabled,
                'indexable'     => true,
                'display_areas' => $display_areas,
                'edit_field'    => array(
                    'label'     => $pair->parent_field_label,
                    'type'      => 'select',
                    'options'   => $parent_options,
                    '_external' => true,
                    '_order'    => $p_ord,
                    'required'  => false,
                ),
                'search_field'  => array(
                    'label'     => $pair->parent_field_label,
                    'type'      => 'select',
                    'options'   => $parent_options,
                    '_external' => true,
                    '_order'    => $p_ord,
                ),
                'view_field'    => array(
                    'label'  => $pair->parent_field_label,
                    'type'   => 'text',
                    'icon'   => $p_bare,
                    'format' => $p_format,
                ),
            );
            if ( ! empty( $category_ids ) ) { $parent['categories'] = $category_ids; }

            $child = array(
                'label'         => $pair->child_field_label,
                'editable'      => true,
                'filterable'    => (bool) $pair->filter_enabled,
                'searchable'    => (bool) $pair->search_enabled,
                'indexable'     => true,
                'display_areas' => $display_areas,
                'edit_field'    => array(
                    'label'     => $pair->child_field_label,
                    'type'      => 'select',
                    'options'   => $child_options,
                    '_external' => true,
                    '_order'    => $c_ord,
                    'required'  => false,
                ),
                'search_field'  => array(
                    'label'     => $pair->child_field_label,
                    'type'      => 'select',
                    'options'   => $child_options,
                    '_external' => true,
                    '_order'    => $c_ord,
                ),
                'view_field'    => array(
                    'label'  => $pair->child_field_label,
                    'type'   => 'text',
                    'icon'   => $c_bare,
                    'format' => $c_format,
                ),
            );
            if ( ! empty( $category_ids ) ) { $child['categories'] = $category_ids; }

            $our[ $pair->parent_field_name ] = $parent;
            $our[ $pair->child_field_name  ] = $child;
        }

        foreach ( $attributes as $slug => $def ) {
            if ( ! isset( $our[ $slug ] ) ) { $our[ $slug ] = $def; }
        }

        return $our;
    }
}
