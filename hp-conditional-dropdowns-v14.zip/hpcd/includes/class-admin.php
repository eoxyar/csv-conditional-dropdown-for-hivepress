<?php
defined( 'ABSPATH' ) || exit;

class HPCD_Admin {

    public static function init() {
        add_action( 'admin_menu',             array( __CLASS__, 'add_menu' ) );
        add_action( 'admin_enqueue_scripts',  array( __CLASS__, 'enqueue' ) );
        add_action( 'admin_init',             array( __CLASS__, 'handle_forms' ) );
    }

    /* ── Menu ─────────────────────────────────────────────────────────── */

    public static function add_menu() {
        global $menu;

        /* Attach under HivePress (hp_settings) if it exists, else standalone */
        $parent    = 'hp_settings';
        $hp_exists = false;
        if ( is_array( $menu ) ) {
            foreach ( $menu as $item ) {
                if ( isset( $item[2] ) && $item[2] === $parent ) {
                    $hp_exists = true; break;
                }
            }
        }

        if ( ! $hp_exists ) {
            add_menu_page( 'HivePress', 'HivePress', 'manage_options', $parent, '__return_null', 'dashicons-store', 58 );
        }

        add_submenu_page(
            $parent,
            __( 'Conditional Dropdowns', 'hp-conditional-dropdowns' ),
            __( 'Conditional Dropdowns', 'hp-conditional-dropdowns' ),
            'manage_options',
            'hpcd-pairs',
            array( __CLASS__, 'page_pairs' )
        );

        add_submenu_page(
            $parent,
            __( 'Conditional Data', 'hp-conditional-dropdowns' ),
            __( 'Conditional Data', 'hp-conditional-dropdowns' ),
            'manage_options',
            'hpcd-data',
            array( __CLASS__, 'page_data' )
        );
    }

    /* ── Assets ───────────────────────────────────────────────────────── */

    public static function enqueue( $hook ) {
        if ( strpos( $hook, 'hpcd' ) === false ) { return; }

        /* FontAwesome for icon preview — use HP's bundled copy if available, else CDN */
        if ( ! wp_style_is( 'font-awesome', 'registered' ) ) {
            wp_enqueue_style( 'font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css', array(), '6.5.1' );
        } else {
            wp_enqueue_style( 'font-awesome' );
        }
        wp_enqueue_style(  'hpcd-admin', HPCD_URL . 'assets/css/admin.css', array(), HPCD_VERSION );
        wp_enqueue_script( 'hpcd-admin', HPCD_URL . 'assets/js/admin.js',   array( 'jquery' ), HPCD_VERSION, true );

        wp_localize_script( 'hpcd-admin', 'hpcdAdmin', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'hpcd_admin' ),
            'pair_id'  => absint( isset( $_GET['pair_id'] ) ? $_GET['pair_id'] : 0 ),
            'strings'  => array(
                'confirm_delete' => __( 'Delete this item?', 'hp-conditional-dropdowns' ),
                'importing'      => __( 'Importing…', 'hp-conditional-dropdowns' ),
                'imported'       => __( 'Import complete: %d imported, %d skipped.', 'hp-conditional-dropdowns' ),
                'error'          => __( 'An error occurred.', 'hp-conditional-dropdowns' ),
            ),
        ) );
    }

    /* ── Form handlers (runs on admin_init) ──────────────────────────── */

    public static function handle_forms() {
        /* Save / update pair */
        if ( isset( $_POST['hpcd_save_pair'] ) && wp_verify_nonce( $_POST['hpcd_nonce'], 'hpcd_save_pair' ) ) {
            if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Forbidden' ); }
            self::do_save_pair();
        }

        /* Delete pair */
        if ( isset( $_GET['action'] ) && $_GET['action'] === 'hpcd_delete_pair' && isset( $_GET['pair_id'] ) ) {
            if ( wp_verify_nonce( $_GET['_wpnonce'], 'hpcd_delete_pair_' . $_GET['pair_id'] ) ) {
                HPCD_DB::delete_pair( intval( $_GET['pair_id'] ) );
                wp_redirect( admin_url( 'admin.php?page=hpcd-pairs&msg=deleted' ) );
                exit;
            }
        }

        /* Delete single data row */
        if ( isset( $_GET['action'] ) && $_GET['action'] === 'hpcd_delete_row' && isset( $_GET['row_id'] ) ) {
            if ( wp_verify_nonce( $_GET['_wpnonce'], 'hpcd_delete_row_' . $_GET['row_id'] ) ) {
                $pair_id = absint( isset( $_GET['pair_id'] ) ? $_GET['pair_id'] : 0 );
                HPCD_DB::delete_data_row( intval( $_GET['row_id'] ) );
                wp_redirect( admin_url( 'admin.php?page=hpcd-data&pair_id=' . $pair_id . '&msg=deleted' ) );
                exit;
            }
        }
    }

    private static function do_save_pair() {
        /* Category IDs – multi-select returns array */
        $cat_ids = '';
        if ( ! empty( $_POST['category_ids'] ) && is_array( $_POST['category_ids'] ) ) {
            $ids     = array_filter( array_map( 'intval', $_POST['category_ids'] ) );
            $cat_ids = implode( ',', $ids );
        }

        $data = array(
            'pair_name'          => sanitize_text_field( isset( $_POST['pair_name'] )          ? $_POST['pair_name']          : '' ),
            'parent_field_name'  => sanitize_key(        isset( $_POST['parent_field_name'] )  ? $_POST['parent_field_name']  : '' ),
            'parent_field_label' => sanitize_text_field( isset( $_POST['parent_field_label'] ) ? $_POST['parent_field_label'] : '' ),
            'child_field_name'   => sanitize_key(        isset( $_POST['child_field_name'] )   ? $_POST['child_field_name']   : '' ),
            'child_field_label'  => sanitize_text_field( isset( $_POST['child_field_label'] )  ? $_POST['child_field_label']  : '' ),
            'parent_icon'        => sanitize_text_field( isset( $_POST['parent_icon'] )        ? $_POST['parent_icon']        : '' ),
            'parent_format'      => sanitize_text_field( isset( $_POST['parent_format'] )      ? $_POST['parent_format']      : '%icon% %label%: %value%' ),
            'child_icon'         => sanitize_text_field( isset( $_POST['child_icon'] )         ? $_POST['child_icon']         : '' ),
            'child_format'       => sanitize_text_field( isset( $_POST['child_format'] )       ? $_POST['child_format']       : '%icon% %label%: %value%' ),
            'category_ids'       => $cat_ids,
            'search_enabled'     => isset( $_POST['search_enabled'] )  ? 1 : 0,
            'filter_enabled'     => isset( $_POST['filter_enabled'] )  ? 1 : 0,
            'block_display'      => sanitize_key( isset( $_POST['block_display'] ) ? $_POST['block_display'] : 'secondary' ),
            'page_display'       => sanitize_key( isset( $_POST['page_display'] )  ? $_POST['page_display']  : 'secondary' ),
            'sort_order'         => absint( isset( $_POST['sort_order'] ) ? $_POST['sort_order'] : 0 ),
            'status'             => isset( $_POST['status'] ) ? 1 : 0,
        );

        $pair_id = absint( isset( $_POST['pair_id'] ) ? $_POST['pair_id'] : 0 );
        if ( $pair_id ) {
            HPCD_DB::update_pair( $pair_id, $data );
            $msg = 'updated';
        } else {
            $pair_id = HPCD_DB::insert_pair( $data );
            $msg = 'created';
        }

        wp_redirect( admin_url( 'admin.php?page=hpcd-pairs&msg=' . $msg ) );
        exit;
    }

    /* ── Helper: listing categories ─────────────────────────────────── */

    public static function get_categories() {
        static $cache = null;
        if ( $cache !== null ) { return $cache; }
        $cache = array();
        $terms = get_terms( array( 'taxonomy' => 'hp_listing_category', 'hide_empty' => false ) );
        if ( ! is_wp_error( $terms ) ) {
            foreach ( $terms as $t ) {
                $cache[] = array( 'id' => $t->term_id, 'name' => $t->name );
            }
        }
        return $cache;
    }

    /* ── Pages ────────────────────────────────────────────────────────── */

    public static function page_pairs() {
        $pairs    = HPCD_DB::get_pairs( false );
        $cats     = self::get_categories();
        $edit     = null;

        if ( isset( $_GET['action'] ) && $_GET['action'] === 'edit' && isset( $_GET['pair_id'] ) ) {
            $edit = HPCD_DB::get_pair( intval( $_GET['pair_id'] ) );
        }

        $msg = isset( $_GET['msg'] ) ? $_GET['msg'] : '';
        ?>
        <div class="wrap hpcd-wrap">
            <h1><?php esc_html_e( 'Conditional Dropdowns — Field Pairs', 'hp-conditional-dropdowns' ); ?>
                <?php if ( ! $edit ) : ?>
                <a href="#hpcd-add-form" class="page-title-action"><?php esc_html_e( 'Add New Pair', 'hp-conditional-dropdowns' ); ?></a>
                <?php endif; ?>
            </h1>

            <?php if ( $msg ) : ?>
                <div class="notice notice-success is-dismissible"><p><?php echo esc_html( self::msg_text( $msg ) ); ?></p></div>
            <?php endif; ?>

            <?php if ( empty( $cats ) ) : ?>
                <div class="notice notice-warning"><p>
                    <?php esc_html_e( 'No listing categories found. Create at least one listing category to use category restrictions.', 'hp-conditional-dropdowns' ); ?>
                </p></div>
            <?php endif; ?>

            <!-- ── Pair form ──────────────────────────────────────── -->
            <div class="hpcd-box" id="hpcd-add-form">
                <h2><?php echo $edit ? esc_html__( 'Edit Pair', 'hp-conditional-dropdowns' ) : esc_html__( 'Add New Pair', 'hp-conditional-dropdowns' ); ?></h2>

                <form method="post" action="">
                    <?php wp_nonce_field( 'hpcd_save_pair', 'hpcd_nonce' ); ?>
                    <?php if ( $edit ) : ?>
                        <input type="hidden" name="pair_id" value="<?php echo esc_attr( $edit->id ); ?>">
                    <?php endif; ?>

                    <table class="form-table">
                        <tr>
                            <th><?php esc_html_e( 'Pair Name', 'hp-conditional-dropdowns' ); ?></th>
                            <td><input name="pair_name" class="regular-text" value="<?php echo esc_attr( $edit ? $edit->pair_name : '' ); ?>" required>
                                <p class="description"><?php esc_html_e( 'Internal label, e.g. "Make → Model".', 'hp-conditional-dropdowns' ); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Parent Field', 'hp-conditional-dropdowns' ); ?></th>
                            <td>
                                <input name="parent_field_name" placeholder="make" class="regular-text" value="<?php echo esc_attr( $edit ? $edit->parent_field_name : '' ); ?>" required>
                                <span class="description"><?php esc_html_e( 'Slug (lowercase, no spaces) — used as meta key', 'hp-conditional-dropdowns' ); ?></span>
                                <br><input name="parent_field_label" placeholder="<?php esc_attr_e( 'Label shown to users, e.g. Make', 'hp-conditional-dropdowns' ); ?>" class="regular-text" value="<?php echo esc_attr( $edit ? $edit->parent_field_label : '' ); ?>" required style="margin-top:5px;">
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Child Field', 'hp-conditional-dropdowns' ); ?></th>
                            <td>
                                <input name="child_field_name" placeholder="model" class="regular-text" value="<?php echo esc_attr( $edit ? $edit->child_field_name : '' ); ?>" required>
                                <span class="description"><?php esc_html_e( 'Slug (lowercase, no spaces)', 'hp-conditional-dropdowns' ); ?></span>
                                <br><input name="child_field_label" placeholder="<?php esc_attr_e( 'Label shown to users, e.g. Model', 'hp-conditional-dropdowns' ); ?>" class="regular-text" value="<?php echo esc_attr( $edit ? $edit->child_field_label : '' ); ?>" required style="margin-top:5px;">
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Display — Parent', 'hp-conditional-dropdowns' ); ?></th>
                            <td>
                                <div style="display:flex;gap:10px;align-items:flex-start;flex-wrap:wrap;">
                                    <div>
                                        <label class="hpcd-small-label"><?php esc_html_e( 'Icon class', 'hp-conditional-dropdowns' ); ?></label>
                                        <div style="display:flex;align-items:center;gap:6px;">
                                            <input name="parent_icon" id="parent_icon_input" placeholder="car" class="regular-text" value="<?php echo esc_attr( $edit ? $edit->parent_icon : '' ); ?>" style="width:180px;">
                                            <span class="hpcd-icon-preview" id="parent_icon_preview"><?php if ( $edit && $edit->parent_icon ) : $n = preg_replace('/^(fa[srbldi]?)\s+fa-/', '', trim($edit->parent_icon)); ?><i class="hp-icon fas fa-fw fa-<?php echo esc_attr($n); ?>"></i><?php endif; ?></span>
                                        </div>
                                        <p class="description"><?php esc_html_e( 'Icon name only, e.g. car, map-marker-alt, tag', 'hp-conditional-dropdowns' ); ?></p>
                                    </div>
                                    <div style="flex:1;min-width:240px;">
                                        <label class="hpcd-small-label"><?php esc_html_e( 'Display format', 'hp-conditional-dropdowns' ); ?></label>
                                        <input name="parent_format" placeholder="%icon% %label%: %value%" class="large-text" value="<?php echo esc_attr( $edit && $edit->parent_format ? $edit->parent_format : '%icon% %label%: %value%' ); ?>">
                                        <p class="description"><?php esc_html_e( 'HTML allowed. Click a token to insert it:', 'hp-conditional-dropdowns' ); ?></p>
                                        <div class="hpcd-format-tokens">
                                            <span class="hpcd-token" data-target="parent_format">%icon%</span>
                                            <span class="hpcd-token" data-target="parent_format">%label%</span>
                                            <span class="hpcd-token" data-target="parent_format">%value%</span>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Display — Child', 'hp-conditional-dropdowns' ); ?></th>
                            <td>
                                <div style="display:flex;gap:10px;align-items:flex-start;flex-wrap:wrap;">
                                    <div>
                                        <label class="hpcd-small-label"><?php esc_html_e( 'Icon class', 'hp-conditional-dropdowns' ); ?></label>
                                        <div style="display:flex;align-items:center;gap:6px;">
                                            <input name="child_icon" id="child_icon_input" placeholder="map-marker-alt" class="regular-text" value="<?php echo esc_attr( $edit ? $edit->child_icon : '' ); ?>" style="width:180px;">
                                            <span class="hpcd-icon-preview" id="child_icon_preview"><?php if ( $edit && $edit->child_icon ) : $n = preg_replace('/^(fa[srbldi]?)\s+fa-/', '', trim($edit->child_icon)); ?><i class="hp-icon fas fa-fw fa-<?php echo esc_attr($n); ?>"></i><?php endif; ?></span>
                                        </div>
                                        <p class="description"><?php esc_html_e( 'Icon name only, e.g. map-marker-alt, city, globe', 'hp-conditional-dropdowns' ); ?></p>
                                    </div>
                                    <div style="flex:1;min-width:240px;">
                                        <label class="hpcd-small-label"><?php esc_html_e( 'Display format', 'hp-conditional-dropdowns' ); ?></label>
                                        <input name="child_format" placeholder="%icon% %label%: %value%" class="large-text" value="<?php echo esc_attr( $edit && $edit->child_format ? $edit->child_format : '%icon% %label%: %value%' ); ?>">
                                        <p class="description"><?php esc_html_e( 'HTML allowed. Click a token to insert it:', 'hp-conditional-dropdowns' ); ?></p>
                                        <div class="hpcd-format-tokens">
                                            <span class="hpcd-token" data-target="child_format">%icon%</span>
                                            <span class="hpcd-token" data-target="child_format">%label%</span>
                                            <span class="hpcd-token" data-target="child_format">%value%</span>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Restrict to Categories', 'hp-conditional-dropdowns' ); ?></th>
                            <td>
                                <?php if ( empty( $cats ) ) : ?>
                                    <em><?php esc_html_e( 'No categories available.', 'hp-conditional-dropdowns' ); ?></em>
                                <?php else : ?>
                                    <select name="category_ids[]" multiple size="<?php echo min( 8, count( $cats ) ); ?>" style="min-width:220px;">
                                        <?php
                                        $sel_ids = array();
                                        if ( $edit && $edit->category_ids ) {
                                            $sel_ids = array_map( 'intval', explode( ',', $edit->category_ids ) );
                                        }
                                        foreach ( $cats as $cat ) :
                                        ?>
                                            <option value="<?php echo esc_attr( $cat['id'] ); ?>" <?php selected( in_array( $cat['id'], $sel_ids ) ); ?>>
                                                <?php echo esc_html( $cat['name'] ); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <p class="description"><?php esc_html_e( 'Hold Ctrl / ⌘ to select multiple. Leave empty = all categories.', 'hp-conditional-dropdowns' ); ?></p>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Display Area', 'hp-conditional-dropdowns' ); ?></th>
                            <td>
                                <?php
                                $ba = array( 'primary' => 'Block Primary', 'secondary' => 'Block Secondary', 'ternary' => 'Block Ternary', 'hide' => 'Hide' );
                                $pa = array( 'primary' => 'Page Primary',  'secondary' => 'Page Secondary',  'ternary' => 'Page Ternary',  'hide' => 'Hide' );
                                ?>
                                <label><?php esc_html_e( 'Block:', 'hp-conditional-dropdowns' ); ?>
                                    <select name="block_display">
                                        <?php foreach ( $ba as $v => $l ) : ?>
                                            <option value="<?php echo esc_attr( $v ); ?>" <?php selected( $edit ? $edit->block_display : 'secondary', $v ); ?>><?php echo esc_html( $l ); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </label>
                                &nbsp;
                                <label><?php esc_html_e( 'Page:', 'hp-conditional-dropdowns' ); ?>
                                    <select name="page_display">
                                        <?php foreach ( $pa as $v => $l ) : ?>
                                            <option value="<?php echo esc_attr( $v ); ?>" <?php selected( $edit ? $edit->page_display : 'secondary', $v ); ?>><?php echo esc_html( $l ); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Options', 'hp-conditional-dropdowns' ); ?></th>
                            <td>
                                <label><input type="checkbox" name="search_enabled" value="1" <?php checked( $edit ? $edit->search_enabled : 1 ); ?>> <?php esc_html_e( 'Show in Search form', 'hp-conditional-dropdowns' ); ?></label><br>
                                <label><input type="checkbox" name="filter_enabled" value="1" <?php checked( $edit ? $edit->filter_enabled : 1 ); ?>> <?php esc_html_e( 'Show in Filter sidebar', 'hp-conditional-dropdowns' ); ?></label><br>
                                <label><input type="checkbox" name="status"         value="1" <?php checked( $edit ? $edit->status : 1 ); ?>> <?php esc_html_e( 'Active', 'hp-conditional-dropdowns' ); ?></label>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Display Order', 'hp-conditional-dropdowns' ); ?></th>
                            <td>
                                <input type="number" name="sort_order" min="0" value="<?php echo esc_attr( $edit ? intval( $edit->sort_order ) : 0 ); ?>" style="width:80px;">
                                <p class="description"><?php esc_html_e( 'Controls which pair appears first. Lower = earlier in the form. Leave 0 to use creation order. Pairs are always shown as parent+child together.', 'hp-conditional-dropdowns' ); ?></p>
                            </td>
                        </tr>
                    </table>

                    <p class="submit">
                        <input type="submit" name="hpcd_save_pair" class="button button-primary" value="<?php echo $edit ? esc_attr__( 'Update Pair', 'hp-conditional-dropdowns' ) : esc_attr__( 'Save Pair', 'hp-conditional-dropdowns' ); ?>">
                        <?php if ( $edit ) : ?>
                            <a href="<?php echo esc_url( admin_url( 'admin.php?page=hpcd-pairs' ) ); ?>" class="button"><?php esc_html_e( 'Cancel', 'hp-conditional-dropdowns' ); ?></a>
                        <?php endif; ?>
                    </p>
                </form>
            </div>

            <!-- ── Pairs list ───────────────────────────────────── -->
            <table class="wp-list-table widefat fixed striped" style="margin-top:20px;">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'Pair Name', 'hp-conditional-dropdowns' ); ?></th>
                        <th><?php esc_html_e( 'Parent → Child fields', 'hp-conditional-dropdowns' ); ?></th>
                        <th><?php esc_html_e( 'Categories', 'hp-conditional-dropdowns' ); ?></th>
                        <th><?php esc_html_e( 'Data rows', 'hp-conditional-dropdowns' ); ?></th>
                        <th><?php esc_html_e( 'Status', 'hp-conditional-dropdowns' ); ?></th>
                        <th><?php esc_html_e( 'Actions', 'hp-conditional-dropdowns' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ( empty( $pairs ) ) : ?>
                        <tr><td colspan="6"><?php esc_html_e( 'No pairs yet.', 'hp-conditional-dropdowns' ); ?></td></tr>
                    <?php else : foreach ( $pairs as $p ) :
                        $cat_names = array();
                        if ( $p->category_ids ) {
                            foreach ( explode( ',', $p->category_ids ) as $cid ) {
                                $term = get_term( intval( $cid ) );
                                if ( $term && ! is_wp_error( $term ) ) { $cat_names[] = $term->name; }
                            }
                        }
                        $row_count = HPCD_DB::count_data( $p->id );
                    ?>
                    <tr>
                        <td><strong><?php echo esc_html( $p->pair_name ); ?></strong></td>
                        <td>
                            <code><?php echo esc_html( $p->parent_field_name ); ?></code> (<?php echo esc_html( $p->parent_field_label ); ?>)
                            &rarr;
                            <code><?php echo esc_html( $p->child_field_name ); ?></code> (<?php echo esc_html( $p->child_field_label ); ?>)
                        </td>
                        <td><?php echo $cat_names ? esc_html( implode( ', ', $cat_names ) ) : '<em>' . esc_html__( 'All', 'hp-conditional-dropdowns' ) . '</em>'; ?></td>
                        <td>
                            <?php echo esc_html( $row_count ); ?>
                            <a href="<?php echo esc_url( admin_url( 'admin.php?page=hpcd-data&pair_id=' . $p->id ) ); ?>">
                                <?php esc_html_e( 'Manage', 'hp-conditional-dropdowns' ); ?>
                            </a>
                        </td>
                        <td><span class="hpcd-badge hpcd-badge-<?php echo $p->status ? 'on' : 'off'; ?>"><?php echo $p->status ? esc_html__( 'Active', 'hp-conditional-dropdowns' ) : esc_html__( 'Inactive', 'hp-conditional-dropdowns' ); ?></span></td>
                        <td>
                            <a href="<?php echo esc_url( admin_url( 'admin.php?page=hpcd-pairs&action=edit&pair_id=' . $p->id ) ); ?>" class="button button-small"><?php esc_html_e( 'Edit', 'hp-conditional-dropdowns' ); ?></a>
                            <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=hpcd-pairs&action=hpcd_delete_pair&pair_id=' . $p->id ), 'hpcd_delete_pair_' . $p->id ) ); ?>" class="button button-small" onclick="return confirm('<?php esc_attr_e( 'Delete this pair and all its data?', 'hp-conditional-dropdowns' ); ?>')" style="color:#c00;"><?php esc_html_e( 'Delete', 'hp-conditional-dropdowns' ); ?></a>
                        </td>
                    </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>

            <div class="hpcd-help">
                <h3><?php esc_html_e( 'How it works', 'hp-conditional-dropdowns' ); ?></h3>
                <ol>
                    <li><?php esc_html_e( 'Create a pair here: give it a name, set parent slug + label and child slug + label.', 'hp-conditional-dropdowns' ); ?></li>
                    <li><?php esc_html_e( 'Optionally restrict to one or more listing categories. Leave empty to show in all categories.', 'hp-conditional-dropdowns' ); ?></li>
                    <li><?php esc_html_e( 'Go to "Conditional Data" and enter rows: parent value → child value. Or use the CSV import.', 'hp-conditional-dropdowns' ); ?></li>
                    <li><?php esc_html_e( 'The fields appear automatically in Add Listing, Edit Listing, Search and Filter — no code needed.', 'hp-conditional-dropdowns' ); ?></li>
                </ol>
            </div>
        </div>
        <?php
    }

    /* ── Data management page ────────────────────────────────────────── */

    public static function page_data() {
        $pairs    = HPCD_DB::get_pairs( false );
        $pair_id  = absint( isset( $_GET['pair_id'] ) ? $_GET['pair_id'] : ( $pairs ? $pairs[0]->id : 0 ) );
        $pair     = $pair_id ? HPCD_DB::get_pair( $pair_id ) : null;
        $msg      = isset( $_GET['msg'] ) ? $_GET['msg'] : '';
        $search   = isset( $_GET['search'] ) ? sanitize_text_field( $_GET['search'] ) : '';

        $per_page = 100;
        $current  = max( 1, absint( isset( $_GET['paged'] ) ? $_GET['paged'] : 1 ) );
        $offset   = ( $current - 1 ) * $per_page;
        $total    = $pair ? HPCD_DB::count_data( $pair_id, $search ) : 0;
        $rows     = $pair ? HPCD_DB::get_data( $pair_id, $search, $per_page, $offset ) : array();
        $pages    = $total ? (int) ceil( $total / $per_page ) : 1;
        ?>
        <div class="wrap hpcd-wrap">
            <h1><?php esc_html_e( 'Conditional Data', 'hp-conditional-dropdowns' ); ?></h1>

            <?php if ( $msg ) : ?>
                <div class="notice notice-success is-dismissible"><p><?php echo esc_html( self::msg_text( $msg ) ); ?></p></div>
            <?php endif; ?>

            <!-- Pair selector -->
            <div class="hpcd-pair-tabs">
                <?php foreach ( $pairs as $p ) : ?>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=hpcd-data&pair_id=' . $p->id ) ); ?>"
                       class="hpcd-tab<?php echo $pair_id === intval( $p->id ) ? ' hpcd-tab-active' : ''; ?>">
                        <?php echo esc_html( $p->pair_name ); ?>
                        <span class="hpcd-count"><?php echo esc_html( HPCD_DB::count_data( $p->id ) ); ?></span>
                    </a>
                <?php endforeach; ?>
            </div>

            <?php if ( ! $pair ) : ?>
                <p><?php esc_html_e( 'No pair selected. Create a pair first.', 'hp-conditional-dropdowns' ); ?></p>
                <?php return; ?>
            <?php endif; ?>

            <div style="display:flex;gap:24px;align-items:flex-start;margin-top:16px;">

                <!-- ── Add single row ──────────────────────────────── -->
                <div class="hpcd-box" style="min-width:320px;">
                    <h3><?php esc_html_e( 'Add Row', 'hp-conditional-dropdowns' ); ?></h3>
                    <p class="description"><?php
                        /* translators: 1: parent field label, 2: child field label */
                        printf( esc_html__( 'Enter a %1$s value and a %2$s value.', 'hp-conditional-dropdowns' ),
                            '<strong>' . esc_html( $pair->parent_field_label ) . '</strong>',
                            '<strong>' . esc_html( $pair->child_field_label ) . '</strong>'
                        );
                    ?></p>
                    <div id="hpcd-add-row-form">
                        <input id="hpcd-pv" placeholder="<?php echo esc_attr( $pair->parent_field_label ); ?>" style="width:100%;margin-bottom:6px;">
                        <input id="hpcd-cv" placeholder="<?php echo esc_attr( $pair->child_field_label ); ?>"  style="width:100%;margin-bottom:8px;">
                        <button class="button button-primary" id="hpcd-add-row-btn"><?php esc_html_e( 'Add Row', 'hp-conditional-dropdowns' ); ?></button>
                        <span id="hpcd-add-status" style="margin-left:8px;font-size:13px;"></span>
                    </div>

                    <hr style="margin:20px 0;">

                    <!-- CSV import -->
                    <h3><?php esc_html_e( 'Import CSV', 'hp-conditional-dropdowns' ); ?></h3>
                    <p class="description"><?php esc_html_e( 'Two columns: parent_value, child_value. One row per line.', 'hp-conditional-dropdowns' ); ?></p>
                    <input type="file" id="hpcd-csv-file" accept=".csv" style="width:100%;margin-bottom:6px;"><br>
                    <label><input type="checkbox" id="hpcd-csv-clear"> <?php esc_html_e( 'Clear existing data before import', 'hp-conditional-dropdowns' ); ?></label><br>
                    <button class="button" id="hpcd-import-btn" style="margin-top:8px;"><?php esc_html_e( 'Import', 'hp-conditional-dropdowns' ); ?></button>
                    <span id="hpcd-import-status" style="display:block;margin-top:8px;font-size:13px;"></span>

                    <hr style="margin:20px 0;">

                    <!-- Export -->
                    <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-ajax.php?action=hpcd_export_csv&pair_id=' . $pair_id ), 'hpcd_admin' ) ); ?>" class="button">
                        <?php esc_html_e( 'Export CSV', 'hp-conditional-dropdowns' ); ?>
                    </a>
                </div>

                <!-- ── Data table ───────────────────────────────────── -->
                <div style="flex:1;min-width:0;">
                    <!-- Search -->
                    <form method="get" style="margin-bottom:12px;">
                        <input type="hidden" name="page" value="hpcd-data">
                        <input type="hidden" name="pair_id" value="<?php echo esc_attr( $pair_id ); ?>">
                        <input name="search" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'Search values…', 'hp-conditional-dropdowns' ); ?>" style="width:260px;">
                        <button class="button"><?php esc_html_e( 'Search', 'hp-conditional-dropdowns' ); ?></button>
                        <?php if ( $search ) : ?>
                            <a href="<?php echo esc_url( admin_url( 'admin.php?page=hpcd-data&pair_id=' . $pair_id ) ); ?>" class="button"><?php esc_html_e( 'Clear', 'hp-conditional-dropdowns' ); ?></a>
                        <?php endif; ?>
                        <strong style="margin-left:12px;"><?php echo esc_html( number_format_i18n( $total ) ); ?> <?php esc_html_e( 'rows', 'hp-conditional-dropdowns' ); ?></strong>
                    </form>

                    <table class="wp-list-table widefat fixed striped" id="hpcd-data-table">
                        <thead>
                            <tr>
                                <th style="width:32px;"><input type="checkbox" id="hpcd-select-all"></th>
                                <th><?php echo esc_html( $pair->parent_field_label ); ?></th>
                                <th><?php echo esc_html( $pair->child_field_label ); ?></th>
                                <th style="width:80px;"><?php esc_html_e( 'Delete', 'hp-conditional-dropdowns' ); ?></th>
                            </tr>
                        </thead>
                        <tbody id="hpcd-data-tbody">
                            <?php foreach ( $rows as $row ) : ?>
                                <?php self::render_data_row( $row, $pair_id ); ?>
                            <?php endforeach; ?>
                            <?php if ( empty( $rows ) ) : ?>
                                <tr><td colspan="4"><?php esc_html_e( 'No data yet. Add rows above or import a CSV.', 'hp-conditional-dropdowns' ); ?></td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <!-- Bulk delete -->
                    <div style="margin-top:8px;">
                        <button class="button" id="hpcd-bulk-delete"><?php esc_html_e( 'Delete selected', 'hp-conditional-dropdowns' ); ?></button>
                    </div>

                    <!-- Pagination -->
                    <?php if ( $pages > 1 ) : ?>
                        <div class="tablenav" style="margin-top:12px;">
                            <div class="tablenav-pages">
                                <?php for ( $i = 1; $i <= $pages; $i++ ) : ?>
                                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=hpcd-data&pair_id=' . $pair_id . '&paged=' . $i . ( $search ? '&search=' . urlencode( $search ) : '' ) ) ); ?>"
                                       class="<?php echo $i === $current ? 'button button-primary' : 'button'; ?>" style="min-width:30px;margin:2px;">
                                        <?php echo esc_html( $i ); ?>
                                    </a>
                                <?php endfor; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
    }

    public static function render_data_row( $row, $pair_id ) {
        ?>
        <tr id="hpcd-row-<?php echo esc_attr( $row->id ); ?>">
            <td><input type="checkbox" class="hpcd-row-cb" value="<?php echo esc_attr( $row->id ); ?>"></td>
            <td><?php echo esc_html( $row->parent_value ); ?></td>
            <td><?php echo esc_html( $row->child_value ); ?></td>
            <td>
                <a href="<?php echo esc_url( wp_nonce_url(
                    admin_url( 'admin.php?page=hpcd-data&action=hpcd_delete_row&row_id=' . $row->id . '&pair_id=' . $pair_id ),
                    'hpcd_delete_row_' . $row->id
                ) ); ?>" class="button button-small" style="color:#c00;" onclick="return confirm('<?php esc_attr_e( 'Delete?', 'hp-conditional-dropdowns' ); ?>')">&times;</a>
            </td>
        </tr>
        <?php
    }

    private static function msg_text( $msg ) {
        $map = array(
            'created' => __( 'Pair created successfully.', 'hp-conditional-dropdowns' ),
            'updated' => __( 'Pair updated successfully.', 'hp-conditional-dropdowns' ),
            'deleted' => __( 'Item deleted.', 'hp-conditional-dropdowns' ),
        );
        return isset( $map[ $msg ] ) ? $map[ $msg ] : '';
    }
}
