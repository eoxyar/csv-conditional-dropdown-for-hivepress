<?php
/*
Plugin Name: HP CSV Vehicle Selector
Description: Adds Make and Model selectors to HivePress Listings from a CSV.
Version: 1.2
Author: HivePress Community
*/

require_once plugin_dir_path(__FILE__) . 'includes/fields.php';
require_once plugin_dir_path(__FILE__) . 'includes/scripts.php';
require_once plugin_dir_path(__FILE__) . 'includes/save.php';